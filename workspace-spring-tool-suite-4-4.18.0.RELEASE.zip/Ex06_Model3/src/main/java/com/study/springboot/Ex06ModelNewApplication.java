package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex06ModelNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex06ModelNewApplication.class, args);
	}

}

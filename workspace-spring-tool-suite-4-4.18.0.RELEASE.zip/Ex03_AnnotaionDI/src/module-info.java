/**
 * 
 */
/**
 * @author h
 *
 */
module Ex03_AnnotaionDI {
}
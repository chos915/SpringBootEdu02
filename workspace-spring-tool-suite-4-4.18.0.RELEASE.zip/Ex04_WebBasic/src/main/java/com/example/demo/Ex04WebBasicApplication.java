package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex04WebBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex04WebBasicApplication.class, args);
	}

}
